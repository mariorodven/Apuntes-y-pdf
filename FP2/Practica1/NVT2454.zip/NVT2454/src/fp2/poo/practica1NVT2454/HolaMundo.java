package fp2.poo.practica1NVT2454;
public class HolaMundo{
  public static void main(String[] args) {
    System.out.println("Hola mundo");
  }
}
